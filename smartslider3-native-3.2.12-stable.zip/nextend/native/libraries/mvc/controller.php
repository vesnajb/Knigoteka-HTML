<?php

class N2Controller extends N2ControllerAbstract
{


    public function __construct($appType, $defaultParams) {

        parent::__construct($appType, $defaultParams);
    }
}