<?php

class N2ModelsLink
{

    public static function search($keyword) {

        return array();
    }
}