<?php

/**
 * Interface N2EmbedWidgetInterface
 */
interface N2EmbedWidgetInterface
{

    public function run($params);

} 